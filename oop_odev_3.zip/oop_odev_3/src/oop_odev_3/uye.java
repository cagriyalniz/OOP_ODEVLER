package oop_odev_3;

public class uye extends kullanici {
	
	
	

	
	
}
